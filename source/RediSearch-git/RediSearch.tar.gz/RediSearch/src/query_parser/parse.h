#ifndef __QUERY_PARSER_PARSE_H__
#define __QUERY_PARSER_PARSE_H__

#include "tokenizer.h"
#include "../query.h"
//#include "../rmutil/alloc.h"

#endif  // !__QUERY_PARSER_PARSE_H__