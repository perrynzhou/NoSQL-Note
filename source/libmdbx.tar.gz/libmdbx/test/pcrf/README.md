PCRF Session DB emulation test

